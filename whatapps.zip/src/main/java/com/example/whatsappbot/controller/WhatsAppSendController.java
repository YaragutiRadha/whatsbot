package com.example.whatsappbot.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.whatsappbot.service.ChatService;

@RestController
@RequestMapping("/whatsapp")
public class WhatsAppSendController {

    @Autowired
    private ChatService chatService;

    @GetMapping("/send")
    public String sendMessage(
            @RequestParam String to,
            @RequestParam String text) {

        chatService.sendMessage(to, text);
        return "✅ Message sent to " + to;
    }
}

