package com.example.whatsappbot.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.whatsappbot.service.ChatService;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private ChatService chatService;

    @GetMapping("/firebase")
    public String testFirebase() {
        chatService.testFirebaseWrite();
        return "Firebase write attempted. Check console or Firebase dashboard.";
    }
}
